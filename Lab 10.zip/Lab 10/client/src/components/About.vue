<template>
    <div class="about"

        <h2>Where have you traveled to?</h2>

        <p>Use this site to keep track of how many states you have visited</p>
        <p>A Vue.js site by (ali d).</p>

    </div>
</template>

<script>

export default {
    name: 'About'
}

</script>