<template>
    <div class="state-summery p-2 rounded">

        <span class="m-2">{{ state.name }}</span>
        <p>
            <inpt id="visited" class="m-2" type="checkbox">
        </p>

    </div>
</template>

<script>

export default {
    name: 'State',
    props: {
        state: Object
    },
    data() {
        return{
            stateName: this.state.name,
            statVisited: this.state.visited,
        }
    }
}
</script>

<style scoped>
    .state-summary {
        height: 8cm ;
        width: 10cm;
        border: 1px #EEE solid;
        background-color: whitesmoke;
    }
</style>
